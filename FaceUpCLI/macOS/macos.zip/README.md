### Open Terminal Run
```$macTerminal>> ./faceup.sh```

after running `./faceup.sh` you should be able to start productivity immediately. I hope you enjoy this.