#!/bin/bash
java -jar "$(dirname "$0")/faceup-1.0.0-jar-with-dependencies.jar" "$@"